Solusi untuk {perbaikan|fitur baru} terkait issue {#1, #2, #3, dst.}

Cek : 
1. [Aturan Penulisan Script.](https://github.com/OpenSID/OpenSID/wiki/Aturan-Penulisan-Script)
2. [Proses Review Pull Request.](https://github.com/OpenSID/OpenSID/wiki/proses-review-pull-request)
