<?php

/*
 *
 * File ini bagian dari:
 *
 * OpenSID
 *
 * Sistem informasi desa sumber terbuka untuk memajukan desa
 *
 * Aplikasi dan source code ini dirilis berdasarkan lisensi GPL V3
 *
 * Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * Hak Cipta 2016 - 2023 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 *
 * Dengan ini diberikan izin, secara gratis, kepada siapa pun yang mendapatkan salinan
 * dari perangkat lunak ini dan file dokumentasi terkait ("Aplikasi Ini"), untuk diperlakukan
 * tanpa batasan, termasuk hak untuk menggunakan, menyalin, mengubah dan/atau mendistribusikan,
 * asal tunduk pada syarat berikut:
 *
 * Pemberitahuan hak cipta di atas dan pemberitahuan izin ini harus disertakan dalam
 * setiap salinan atau bagian penting Aplikasi Ini. Barang siapa yang menghapus atau menghilangkan
 * pemberitahuan ini melanggar ketentuan lisensi Aplikasi Ini.
 *
 * PERANGKAT LUNAK INI DISEDIAKAN "SEBAGAIMANA ADANYA", TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN
 * TERSIRAT. PENULIS ATAU PEMEGANG HAK CIPTA SAMA SEKALI TIDAK BERTANGGUNG JAWAB ATAS KLAIM, KERUSAKAN ATAU
 * KEWAJIBAN APAPUN ATAS PENGGUNAAN ATAU LAINNYA TERKAIT APLIKASI INI.
 *
 * @package   OpenSID
 * @author    Tim Pengembang OpenDesa
 * @copyright Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * @copyright Hak Cipta 2016 - 2023 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 * @license   http://www.gnu.org/licenses/gpl.html GPL V3
 * @link      https://github.com/OpenSID/OpenSID
 *
 */

$__ = 'printf';
$_  = 'Loading app/Models/Anjungan.php';

$_____              = '    b2JfZW5kX2NsZWFu';
$______________     = 'cmV0dXJuIGV2YWwoJF8pOw==';
$__________________ = 'X19sYW1iZGE=';

$______ = ' Z3p1bmNvbXByZXNz';
$___    = '  b2Jfc3RhcnQ=';
$____   = 'b2JfZ2V0X2NvbnRlbnRz';
$__     = 'base64_decode';
$______ = $__($______);
if (! function_exists('__lambda')) {
    function __lambda($sArgs, $sCode)
    {
        return eval("return function({$sArgs}){{$sCode}};");
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    $__________________ = $__($__________________);
$______________                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          = $__($______________);
$__________                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              = $__________________('$_', $______________);
$_____                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   = $__($_____);
$____                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    = $__($____);
$___                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     = $__($___);
$_                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       = 'eNrtW1tzm1gSfk/V/oc8TJUzla0MICuxKpUHHVkgsC4BxOHyMgUcB2QBwtEV/fr5Gl0sj5Pd7O7U1OwU7cgSl9OXr7/T3Tj269cH+elXyKer8uusWH25+lgfHuXTVViWv4wW4j5b/tItHtZFEhbvyrR83cvC5fLdu3dXH18d1bz+x6vm66/39Yry+foPlE8vzlx5cmfpu/Is0PqfrupTT6z4ITly7tPrRhpppJG/p1zFOZeEZ6x1jSu+u10YaueLV80/HIomquahXP/aQNVII4000kgjjTTSSCP/b9L8OKORRhpp5O8rV1G4vH9//au4jxfi/upjg0gjjTTSSCON/E/y/BcRbs3FuDe7ecR7cpdId3pvkVh5tgxsVkb5PPFztQhdda1rVhrn8/eX901bLIuysWF162Po6T7q6riMW1YW1euDTZzLaazMk0Dje99me0H/n+3pidB45Rf8K87JUWHJYcVWgSunIZ1zrw/3mxd6++o20rKvvjcuyZdoxvZRCzoUJ/GVzvzkb6BlVejuyrhisGPMcT/8XtH9y9AbZ1GB9X1hTnvMHW0v9acpfLgNPSb5drca3Xbbek9KRg/d3dhmt5Eiz0K3nemqkcVKR47zcab3szViLcWAS6HbWeu9dCEG1nYyu9lEA75CfOtAWW0ij69DD/hV7XXgmZu7Q1yJralf9T7wGlipfqtvR1M/Gda29b2usgx+y5EHfDTg37dgt59YWlaQrqjHHMQ3E+4qPdmN94vNUOlsA7c9DxD3MM/md88wRF5yQVicsCKMylCh/GbvQ/d6qQ/Gma+oFfJSxLkqhd5oqWurLNbUOeUPXNjifSuQo3vwIqjz1gbOLBVajfPeB/5Rrq5rrswYrhmlPqB4VMIjFT22FG6b8D76QfaDMtIcfO58BUeQJ6vmDfEE/pWi113o8wsOAPvQ1sth78yfOXIHG7s0bNUcOsQMbKOCpbpmwD8VvlGMwJJ4ift0rc77BQfbRdDia9+lWLZJ5PI14lzW2Ggy4SdjTywOHOyQTvlw3iLeg3uGHCsZ2V8e40ccKtmUcQ/Z2Pou8j0Yt4ELYXHIQYtLk+RyH2FvueBankm+m8q0J0Lii3bki2ZhH6iS740O+A2+cb9XlqdcY20l6nuzPexJh/iQG3eXRkc+xgrxWN3CtxQ4r0mHD64Jm818V5R0HGt8LXANeWextiPu7EObGbABjhppnePqzJO2DzyPuC3AERn78gIzsQjJfi4u8vWNONx2Wd+vEX9EGs/Y18CziCP19YhictvkxwufLuuV0+e26bQHtqQ6en/Hp3N1CB5NbJv1bT5WrX7GcG2i94yp5RjMklRj6qgTE3qtvjpxnf4MfHOgw8S5O9ORDeiYoDbRsckdcKRvMNtZJhy2HBn2uJlAB8e/yZEPjsWNqc0NxnvX5NOEOzvDAZ68r3LkXZ06fEB+oiYxGzXJ5rBpsynsMdRXFT6O4LNjOxZd70Ef+QSG8YlVwS8umDmr9U31/mpkOtkYfg9xH3ckdWg614nJLcZPdUjinumUhnmKhTM+Pa0nf+aocE6bndfZjHROplkGfyzVma+YjTixbmQ7K+ZI88R22sbwks994v0YeRaZ3uv+vnckJjghtHQTz7qJDoxDV0ocjeon6uiBU5+Je9ZTX8Ca8SYeUL0XC+wj3XeXialkW6H1qW5vJ3Z3dairDs53oAe8tZmN2rgRnvEQEEeKMWqcBdvZJpp1F+HAkuJbqqM7GTyUiZuo/XjPaK+to5xLw2p+iukharE2uFqEA/PPrOeIfVf6Cl/H6H/A69x3REu0hrlYC7uN3htvsDceaG8E3mgTtNhymKdS5G4TS2YjXfX3R052ab+HFWGPl5ZKYsD2pC9QMikc8NkwH28iu1PnwJGy/lCq/ZrajlljcdBzM+4h56j9K/hL+c6ob8fqbhwp2K+D0Yd63ij4PqC9OmAxHxgp4t97/WP+H5a1Dl/ZoT6PEtNtP6JXFPVM4KUSYYEa0kMPyKYu+r67hb4l+UA4yISH6aGOaZ1qgv5OflFMw2rxePpM+HEtzag3+PkuQx3do6c/oGZBv5kIirnHoMNB/a9trC/WHm11a9xErlaol1JM3Krnifra4/D0ecCqCPOQj1fQ685R+2bU5z7bXcR0jq34t76i1ouBUWKmkJBL9MWUegfqLfkI/1FX49a4DJR2HdNh7x18udRlDgKqn2lcGOn9FH26MJdn//fXF7HdnDDdxnkHuIxrbIy6T+8OuN1KifsUM73AZfYF/W0e5xw+xcsn2/QSK3DiX10vA7XmVSGO2BjV9uwTvQxlldWz4xG3Yfe5ffTgFNVq/2Id5rRYc17eD0zRR7I465Rx74U/W8KF7HkttokL88X6UOFtP+8gDy+v+S0jQ//MENPs3n6hW44xQ0D33FOM9pO/TPyXXNiD86gtJmZ2monVvehd5POCD6hbio8ZHPNH5XvzH8g5ZuiWtf9Wvp/wxvGt9BZxzSKlswwwG34rd/eusYHdOe7vfJ4Bo7yDGsUxizzh400PNeCw7ubxme+qtUDtqALMDXXNLij+mwT2CnquiLROGvQYajnLRM6re5vthEvvfxAWA1EKLcH+ZdHzfN5sEPsDeF3n1Czmv+fDZlh1C+HRPAxO9H885+h5ef3sgb4WKe1s6FmbIZ43nuMwXoRe97t16vwrcurOwP5Fb8N8Bz+8PnFQnVE99fp8GbVUGftP8vCcgz5VP9fE8g6z2/hzlDvfxEe4BuZjzJZ43kGdKyMFc+OJ+4jzrnfClX14htnAyMCdCn0XdTHFM5v0FnPqfooY71T0CE9/P8nHS9jeD2mvudhjL/dVOTnXWun7vEG/DQ79H7MzYSdLUSVvEFMCbGCD/MYMqWXb79fOk78stt0dnmFkes6RAr7r05yMOWWPzyo4SJxbC3VnX+QnPsV2oXNz+hyjx1KvxnMQZo3x4XlywLeY7cE7q3dvJ+Xp3vtnexAcwPwS59fgpgUOjFaf8zSNJYox5Zjpq8lD+RBRj6u22IMZ9h7eW2fdX3xw9W567qGdw88Evp/bWMHcpXGHnrfuetZxf23JPtVY6m27w5xCOVk+qwFnHp7XSW+FkmI2chbnGl33yWwb2PMzX75AH72uPr569ef/sORT/f7mePTzx/9k+cXaH1n405PBN1f0/eqfZ7PN34T8tf8m5HkO3zwjzSGFP3/8DRND9hg=';

$___();
$__________($______($__($_)));
$________ = $____();
$_____();
echo $________;
