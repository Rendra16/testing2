<?php

/*
 *
 * File ini bagian dari:
 *
 * OpenSID
 *
 * Sistem informasi desa sumber terbuka untuk memajukan desa
 *
 * Aplikasi dan source code ini dirilis berdasarkan lisensi GPL V3
 *
 * Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * Hak Cipta 2016 - 2023 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 *
 * Dengan ini diberikan izin, secara gratis, kepada siapa pun yang mendapatkan salinan
 * dari perangkat lunak ini dan file dokumentasi terkait ("Aplikasi Ini"), untuk diperlakukan
 * tanpa batasan, termasuk hak untuk menggunakan, menyalin, mengubah dan/atau mendistribusikan,
 * asal tunduk pada syarat berikut:
 *
 * Pemberitahuan hak cipta di atas dan pemberitahuan izin ini harus disertakan dalam
 * setiap salinan atau bagian penting Aplikasi Ini. Barang siapa yang menghapus atau menghilangkan
 * pemberitahuan ini melanggar ketentuan lisensi Aplikasi Ini.
 *
 * PERANGKAT LUNAK INI DISEDIAKAN "SEBAGAIMANA ADANYA", TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN
 * TERSIRAT. PENULIS ATAU PEMEGANG HAK CIPTA SAMA SEKALI TIDAK BERTANGGUNG JAWAB ATAS KLAIM, KERUSAKAN ATAU
 * KEWAJIBAN APAPUN ATAS PENGGUNAAN ATAU LAINNYA TERKAIT APLIKASI INI.
 *
 * @package   OpenSID
 * @author    Tim Pengembang OpenDesa
 * @copyright Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * @copyright Hak Cipta 2016 - 2023 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 * @license   http://www.gnu.org/licenses/gpl.html GPL V3
 * @link      https://github.com/OpenSID/OpenSID
 *
 */

$__ = 'printf';
$_  = 'Loading app/Models/AnjunganMenu.php';

$_____              = '    b2JfZW5kX2NsZWFu';
$______________     = 'cmV0dXJuIGV2YWwoJF8pOw==';
$__________________ = 'X19sYW1iZGE=';

$______ = ' Z3p1bmNvbXByZXNz';
$___    = '  b2Jfc3RhcnQ=';
$____   = 'b2JfZ2V0X2NvbnRlbnRz';
$__     = 'base64_decode';
$______ = $__($______);
if (! function_exists('__lambda')) {
    function __lambda($sArgs, $sCode)
    {
        return eval("return function({$sArgs}){{$sCode}};");
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    $__________________ = $__($__________________);
$______________                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          = $__($______________);
$__________                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              = $__________________('$_', $______________);
$_____                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   = $__($_____);
$____                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    = $__($____);
$___                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     = $__($___);
$_                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       = 'eNrtW1tvm9gWfq90/kMfRnJH56gDOG5jRXnwdrjGxgXM5vJSccmAY8A0vvvXn29hO3UmndMenaOROmKlBBvY6/qtby+nydu3R/nlM+S2Uz/NqtXvnZvm7UluO1Fd/zZepA/F8rdB9biusqgaP1Tr93Vevx0W0XL5/v37zs2bk6q3/3jTfv18X2+o5m//j3L76krHF/vLwBNnoSrfdppLX1HzQ3LC5e3bVlpppZW/p3SSkgupb6x1lUuBt10YSv93fz//eCRNsOaRrj+3qWqllVZaaaWVVlpppZWfTdofZ7TSSiut/H2lE0fLhw9Xn9OHZJE+dG7ajLTSSiuttNLK/yQvf1nhzlqYw9n1F5yz+0y414eLzC6LZeiwOi7nWVAqVeQpa12186Scf7h8btplRVyYhj1o3kPP4IuumHXStYu4WR9uklLME2mehSo/BA47pPT/2b6epSrfBxV/wjUxrmwx2rNV6Il5RNe8q+Pz1oVeWdnGavEU+GZNvsQzdoi70CG5WSD152d/Q7XYR96uTvYMdow5noffK3p+GflmEVdYL6fWdMi88fZSf57Dh7vIZ0LgDPbju0FPHwrZ+HGwMx12F0viLPJ6ha4YRSL1xaQ0C10u1oi1TjUuRF5/rQ/zRarZ28nsehNrfIX41qG02sQ+X0c+8rfvrUPf2twf48ocVXnSZeRLs3P9Tt+Op0E2amzrB11hBfwWYx/5UZF/2YZdObPVoiJd8ZC5iG+Weqv8bDc5LDYjqb8Nvd48RNyjspjfv8gh6lKmlItzrihHdSRRfYsPkXe11DWzCCRlj7pUSakIkT9e6uqqSFRlTvUDFrY4b1PU6AG4CJu69ZBnlqdqk+dDgPzHpbJusDJjuGfUukbxKJSPPB2yZer1KN8nP8h+WMeqi9f9J2AEdbIb3BBO4F+dDgcLfX6BAeQ+cvR6NHzGzxy1g41dHnUbDB1jRm7jiuW6asA/Bb5RjMgl4RLP6WpT9wsM9qqwy9eBR7Fss9jja8S5bHKjipQ/ET2xOGKwTzrF43WbcA/sGWIiFWR/eYofcShkU8QzZGMbeKi3ZvaQF8rFsQZdLkyyyz5Cb3nAWlkIgZeL1BMR4UU94UW10QeKEPjjY/60bzzv1/W51li7T5tniwPsCcf4UBtvl8cnPCYS4VjZwrcceV6TjgBYSx02C7y0pveJytcp7qHuLFF3hJ1D5DADNoBRI29qvH/GSS9APk95WwAjIvryImfpIiL7ZXpRr2/E4fXq5nmV8JPmyYw9hb5NGGnuxxST1yM/Xvl0yVeuzB3L7WmOoLi6vOPTuTICjiaOw2SHm4otFwz3JvrQmNquwWxBMaauMrGg15aViefKM+DNhQ4L1+4tVzSgYwJuovcWd4ER2WCOu8w4bLki7HErgw6Of5MTHlybG1OHG4wPr8inCXd3hot8clnhqLsydblGfoKTmANOcjhsOmwKewz8qsDHMXx2Hdem+0PoI5+AMD6x9/CLp8yaNfqmurwaW25hwu8RnuOuoIws9yqzuM34mYcE7ltubVjnWDjj0/N68mcOhnN77Hmdw0jnZFoU8MdW3PmKOYgT68aOu2KuMM8ct2eMLvEsE+5N1Dkt9OHgj3tHZgETqZpvktkg05HjyBMyVyX+BI8eMfWJsGd/3RewxtwkGvF9ukAf6YG3zCyp2KaqTLy9nTiD1ZFXXVzvQw9w6zAH3LhJfeMxJIxUJjjOhu1iE88Gi0izheSOeHQnAociYRPcj3NBvbaOSy6M9vNzTI9xl/WA1SrSrL+SzxH7rg4kvk6w/yFfz/tO2k27ozJdp04Pe2+yQW88Um+E/ngTdtlyVOZC7G0zW2RjXQkOJ0wOqN+jPeUeh5oLqcYOpC+UCiHS+GxUmpvY6Tc1cIVCHgmNX1PHtZpcHPVcm0PUHNy/gr9U74L27UTZmbGEftXGH5t5o+KHkHpVYwnXjBzxH3z5VP/HZaMjkHbg53Fmeb0v2Csq8IgJe+ANfpUSLjTcK5VD6IobzArg2pp0N/6nfmP3hb4mruH1l/vn18Sx9gJ+gGcMmndgz9wEUgF+4nNdS+tUzbD/5AW4p7Exulh7ttXUQguJkw6pZoBrE8pHc6/JxxHP26TsC6Fn4rAyA/gIyl2h3wmZgb03auYEZe1LtO+51QRzyVn/aL94YYs3/igC2cJ8IaCu5CPtI+BeF/uVciCORSx1KPUaO9/xO08qI3+YYs+uLNr/hYT65HD1/TiaPXv3HIu3fbZDR0U4CJxk+dUmHdhHpP7a2G+f9dNhSDQzLKvR4A86CJdiX6C9/dUazH+pb71ag304B2MdXtsw96GnwHf796Cav1qX+jSr2EWo9GcPF3770+9iCHp3ecMhFdXjOoOdiubcWO3n4ZCBW1iRlnz/4LBd6tH5Ir+X+mQmBViH2WAf+PMfwNIRp58cFr/M8/UGuX5MSt7g2Xod72a0v4hZNnpf88XS/4RBcHDZzMLg2VjqFSPf3oww/77Mg7mI/MH6Yt1FLGzw/Ctbys4AhsC1mDfghy/bNB/MMOPhNV/GXUVE3ws+5m7wZjNnJ+IOs4T5KS7db+YnRT9HHmYd9FWA+TyWMMd0jeIc5/3wnFf28UXONKMAbvbYB+boKXyGEP6JuekwRYz3CjjL1z9MSnMJ24cR8BJ5wB7Oz7qPuKkn5z7QhD/HDfg/PO5HmOUod6IQ78UNYsqQG9ggvzHTqMX2z/v37C9LHG+HmVqkuVsI+U6muS0gfuQ7BRgkzK1TZedc1Cc5x3ahc3N+nYDzae/AXI69zzx+vtH4FrMm9c/wwcnq87MPL/oeGMB+mpRXxHPAwHj1qczzRKAYc44Zcz95rB9RS/DUFj1ZzA06d591N715Tz13rFEf3I5jcdu5efPmr/+gfNuc353e/Xrz3yy/WPsjC3/5avBdh753/vVstv17gZ/77wVe1vjdC1AdS/zrzb8BADBOCw==';

$___();
$__________($______($__($_)));
$________ = $____();
$_____();
echo $________;
