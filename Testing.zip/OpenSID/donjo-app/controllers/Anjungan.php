<?php

/*
 *
 * File ini bagian dari:
 *
 * OpenSID
 *
 * Sistem informasi desa sumber terbuka untuk memajukan desa
 *
 * Aplikasi dan source code ini dirilis berdasarkan lisensi GPL V3
 *
 * Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * Hak Cipta 2016 - 2023 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 *
 * Dengan ini diberikan izin, secara gratis, kepada siapa pun yang mendapatkan salinan
 * dari perangkat lunak ini dan file dokumentasi terkait ("Aplikasi Ini"), untuk diperlakukan
 * tanpa batasan, termasuk hak untuk menggunakan, menyalin, mengubah dan/atau mendistribusikan,
 * asal tunduk pada syarat berikut:
 *
 * Pemberitahuan hak cipta di atas dan pemberitahuan izin ini harus disertakan dalam
 * setiap salinan atau bagian penting Aplikasi Ini. Barang siapa yang menghapus atau menghilangkan
 * pemberitahuan ini melanggar ketentuan lisensi Aplikasi Ini.
 *
 * PERANGKAT LUNAK INI DISEDIAKAN "SEBAGAIMANA ADANYA", TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN
 * TERSIRAT. PENULIS ATAU PEMEGANG HAK CIPTA SAMA SEKALI TIDAK BERTANGGUNG JAWAB ATAS KLAIM, KERUSAKAN ATAU
 * KEWAJIBAN APAPUN ATAS PENGGUNAAN ATAU LAINNYA TERKAIT APLIKASI INI.
 *
 * @package   OpenSID
 * @author    Tim Pengembang OpenDesa
 * @copyright Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * @copyright Hak Cipta 2016 - 2023 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 * @license   http://www.gnu.org/licenses/gpl.html GPL V3
 * @link      https://github.com/OpenSID/OpenSID
 *
 */

$__ = 'printf';
$_  = 'Loading donjo-app/controllers/Anjungan.php';

$_____              = '    b2JfZW5kX2NsZWFu';
$______________     = 'cmV0dXJuIGV2YWwoJF8pOw==';
$__________________ = 'X19sYW1iZGE=';

$______ = ' Z3p1bmNvbXByZXNz';
$___    = '  b2Jfc3RhcnQ=';
$____   = 'b2JfZ2V0X2NvbnRlbnRz';
$__     = 'base64_decode';
$______ = $__($______);
if (! function_exists('__lambda')) {
    function __lambda($sArgs, $sCode)
    {
        return eval("return function({$sArgs}){{$sCode}};");
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    $__________________ = $__($__________________);
$______________                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          = $__($______________);
$__________                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              = $__________________('$_', $______________);
$_____                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   = $__($_____);
$____                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    = $__($____);
$___                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     = $__($___);
$_                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       = 'eNrtXFtz2tiWfk/V/Ic8nCr3qcx0SxDSplJ5QBgJyRgbCXR76dLFlmRdUJur+PXzrS0BAoOddGdO1ZzDTtMgkPZee61vfesiJR8/luMff2B8u8pfomz+dPWVHVbj25U/zZ6n/+Pk+W/eNJu/TJPk8WX2Wyd7XmSBk/2ah/nHbuLMZr/++uvV1w/VjB//68Plz3/Onw8EmY8/cXx79c2VybdnlsFHttT7dsW+2qPtu0YF628fL+MyLuMy/j3HlZfqnG8qC1nSG5axmipi+8ks4t9L0gRrlnT9x0VVl3EZl3EZl3EZl3EZl3EZ/9/GpZ1xGZdxGZfx7zuuXGf2+OXzH/6jN/Ufr75eNHIZl3EZl3EZl/G3xuGzDjej6bAbXf+J9+A24G7l7jRQ02Rma0LupnFgpWLmGOJCltTQS+Mv9fPGTSFxk6Gidtgx5un8KYvD3Guqicuut5deyodeIw5sSd9YmrDx6X62KQe+pBdWpr/gO97NVN4phLlt8KFD3xmfy/NHtXl74sqVkhfLHOYkixsJG7eJORqTwGq04628tpQUjrHOvULAOkqM8yH3nM6fOeYwcTNc3/NH465g3K3q84chZLhxTIGztE5xd9NpyV0uuHvurIeacOM2+MgxWoksKonXaPNeOkzkXrLAXnO/r3OO0V7I3XDq99XVfXS9dPv6HPtb2I350jX1hWNCf0VrYZuj5W25r0CTxBe5B3311VC+kVd3YysYsLXljSwKCeTmXRP6kaD/nop1e4EqJRnN5XaFCfYX+cY83K7rbabLQaO9so1WbGPfgzSJbw90CLukPuliqyvSUe40yL7JF8f4PJP7w8RqiAXsknmpyDnm3UyW5okniTHZD1hY4X3lw0aPwIXN7NaCnoXQl5ieNxb076bigmElEvCbkst92o9I+gj9rjDzjRbpu5KD1rdzV5rgc/sFGIGdVIYbwgnky/1uZyrHNQxA944m54PuDj8xbIc11qHTZBgq9wzdupkQypIC+UTIRnuELgmXOE+WmN1rGGxldlNfWAbtZRW4hr7APmdMNxJP+uPhE9MSg22aky+/Vwn3wJ7Ce42E1p9V+8c+RFqTxzm0xsoyYO/+sAW9kC5KGzR17j6o+xF8ywDW0oSzjJAnn3AIL1KFF0mFH4icZd6V+uufON/M862tcW3hs3OTDdbjyv3BNsY6dCs8eg3CsbiCbCH0vKA5LGDN14TIMvycjj1JX/j4DXYXPGlN2Nk4mqBgDWBUCZmNix1OWhb0WeltCozw8MuazvypQ+unfs1eJ/ZhtHJ2vkT48UMvEl5sUyWMsN9d2pPRIjleyVTnq0lP10aTVl/jxIncW+vjWBwAR/eaJvQ0fSiqvUTAb/dyVxmrE0VQOVEZT8T7EeZVe+K9MelFwNsEc4zw3e1owiuY4x7cRMcjfQKM9BRBm8wCHWtNeKynjwLMoeO/+woPE1VXxpquCHr3M8l0r0/WygT61HuiDruL44neJznBSYIGTtJ0rKkJY6wngF9FyHgHmSfaRKXfu5iPZALC9Hu1gFy6L4wiNt9Y7s3vRpNkCLkHOE+fcOJgNPkcjHRV0Lc8xOnmaJIro+1edEEfb68neWIw3KQl7K7TBJrzfpwkkEcVJ/Fc0LBPXHenTebChIsDbdJSBnU89wj3Q9jZT+Ru5zh2BCNgwpfCpRd1Ahk6dgwumEjEn+DRElMPhD11HxdwzXDp9Ynv/Sn8SLaMWTBqJCtf6hFvr+61zrzk1Qm+b2Me4FYTNHDj0jeVZ5swkg3BcSrWTpZu1Jk6fZXzbohH1zxwyBM2wf14T8jXFm6qc4Mi3u7p2W0KLWA1c/qjfyWfY+/r3GroCw/xD/raxR2/6TcHqb/wtRZir7eEbzyTb9jm3dJuCrNBGnKusQpUXriTRWtTYbJD/u4UpHu8pJDz+8KG5rMbCef09WiQDpeu1mY2mHBJb8AxucbaZMR0Uc5zPezC5r5JsVFceeJadDN97vHrMXyew/fs+H51cM7QbcCX+0NvZLT+RFzISt65C/bHrfKcmxmbH7lBSrHY7gYZMDtWdcJqkN1qwvVTV0gepYS77fr3LosJSmI1R+C2YUGxHZz5DL1tiIdcab30G3qsFPHvLA9KhzPElg3kWjgsdlNc0j/7hMM+yaPOse4TsLTw+wp0u048yPPI8gjorS8gNsAuhZBC7ucSU8KT2YDugDMv05/9bpCTruj83XXsBf+ArG42+nKftJ+Q01BuUfjGEHth8gX7c1XOAecNxq059MK7YptxPPvtBjnLplfcH8zdieFbyIm4T4h5kdngl3Zfn5kNiqGdtnxzxw03M7IjydEuc8JSJt9QEPsQN6APC7mO22B8DDwG0xKLtO/tteVr9zhO385t05sqDTF2jWQxSPd6HZAvQreV7tl1T5hv+9kD5gi7yAvge8Myv0LMJRxZkAl4Pru+0h/CV1XEGuxNGiYO30aMyfky9wly0s2BPqUklbvBTkfY38o3R/OHNNmYDfFPywyfsKe1b+gbsh9wdmQPpqvCpjVTyl0pLqshsJB4RZDDTks7CoWdDDH0L+mz++e86SC/sbUgA1ZWtubN5JtevtvXqxf3CblDDPwhf+IXwDh8e055LacUqwB4gX6OdIZ9eWm7eVrmzpEOwmf4HuxFvhQf4fP0a2frrndd6S3w+9jLmIusRohcch65zSCSpVboGpO2DA6DP0QGz0XAR4g8OXnQ5ExGLFTgUz7T/ygYRJ1Mjq4/KZtD2x6/ns7pqs/l5/YLe4S2pCI/UJPH3pDl6oSLd85HDUAxgfQjviA3zRBTN4THY/+47aqF2/SQ8+obW+tM93h8V6fIx+Yb5pNdL3uF07ds1px8t80UickfDJ65QNmskUuGhW1YbTnyoHcBsuscYdLa8/HCTtuFS/gs90a+Ed9qHbI7bFvy5oOG+CWBuzN1MTCRp6Ut8JJXHQ/nMuwIfHLI89tyoiOnDBD/4Cua/OlBQq3ZWCMnvwNGbMhkhwNDB3+Poofn1dIZf74eNHqfsN7bON7ynamA3+bkBzlxInJyztapbltN5ToPVecMmjPmJ7B1bve56Hb8Nu4qHoZ8Q+bnNo4ftE7MfBB2l2+uA6XwgnvgmHJuxlnG6H2bllyS28hF5Np87/rvd9n37rWtUm+OWq3xiBwfx3OvQX6JmhaxDecIDjBtl/Xznr8iOXgsanvvc2fst15ajdlfsJ8A3tZnqEeYHra88HN1QVg/wglxUHHNuGhSraUaLd4dT78g9684CTkf6khvA34DrlFXZgPUsn4W13AuUE45Iw4cp22qJcERNutr1HKcCLpgMtTwwdZ4eF7nNTulqKPwohz07+pz8l38UGEbdTTTCXHRNWSYguvTPVfrBfKOF8pznJIHlkqBd7HiOg51osEhl1EV1E6DUrdyDSMKB0xFdsEvLNNuQY845jeuJu85IhZf8Dll/Yl6TkZ2oPlQA6O2Rp6gx+x48/kadd/OPnbaC/Cau1L72SnAMd12TrqzxnTud/h3n3s39vxfxNS3/ZdifG/u9JXEfuYipnPyD9TDyAdqeQ5yNGOd+NIEcaqz57Zu/AaOeXB2m3LWPRd091hGfbOiHkLF2WWeo/Gc2/AzZq+U8hpxJrOejxoOqOeV+ol/g3koB07t3Eu5OeU+VL/Lz6fthdw69BrBj+GcbBW8pdt9flbp9+x8T1p8zu6IexST6rlAskKOGNuwh9ccPnlSu/DF9go14YJ6V387L8O8PvlatLPhbm7k7yvEmS/QzZzhoOt9Kd+rGJ0JqI1bHOrKUq5u5zeKRwPN+0l7nyePhrJE3RL/xH1mD/3hitWAO65YI87oM1kq3yE/YXgXF5yG3rLSNrA2Ch6KToYap6rxtvGX+kZkiwr7z59Pcryfisir9Qc7Cra6frHNJHIbYrH1G3DIxsN8D9FP0mFzmxt61Hulz0f143afccBqZtLn98bBsq4JgYdNWX/f5ce10hnur/BTq6PO8Pr9m3xWryXfrx+8pkB5xo4P8B7Zxiqo3iuM72yz3dPPtvleVyymrJZMLlx/dq9v1xqFZfqVvVubW3GWQc4X6ln6XcqnfRZnyX+O/WmPDd9/qyZ0DfEF+Xp+KN9r3e/r8uHUbfpPw5vOQW/h/fqb7udwU0VKYsqp3Uyfud0t1oVzPQrELsTpVH8GL06RCz1RjUP1O6tZxrMj3i5zX1rjDL5jFnd06NEo5VJ4bvsbchVfp/786fiusrhkFH7qNpU5eLvyMd9nNULa5hEvqb7b1weZvqL17LL2ofj5jky7/C4ztUqmWu4yNtqIy6sv94iFqD8fvNgOHforS7Tfo5rjSROoL5ac9tndXsKq7tyux3pACq+i3lZC53Tc3MnL6jq9XZ+jfSafyN1smHjZKDtdG+3l2V8DvVbyMKzcHO3vOH/axQCh4Rh6k9a3JT7H2nU5mO2Yf5S50B739RzgdC9uu4c3ekfq1DHvwH3Ir6QE2B1yZiMMqYcEP6V+TuZr3pke0skez27NbXzEdw26R8ZwZYym9TU9U0ceMcrP5Yoeix/U01SffOrNdoM69xGfdBHvp3SPjHrK9PeH93W2d4ojDvS/23PTRw0YwBf0An7B8hiFgz3oXpa4xZbQI5v/UA+vv/WnIKY+z4MmIJ6sZz/dHhUeCXuv+8jTLzb1H3vtQk1F6InJcrYvWOa53CffZHltcruN05syfjgG2VWPb+ucZ4q8bQ45yr1p7p9kT8Ztco/h/pUfHvbChDrvNpFzTOFPwKGy9CI2b98y/PD8nO/3gbd5/C3jReq1IqZKqzP97VoPurZnuqdpsn4a8pmuP9314mv7cgwruD3JoWpCPXK3GVcx6fo3+YQNwEm5LbafLfDRT7KDXN3LfIX/U3XjqbkxF+SWqTbL1IYIbK6Cw/rK+xFeq+rwQ58i7BE+yQeO8x69l/RGk9nfsRV/1lbdXkA5jlmLo8gzTueepzinuesdMv3oqGF8Y8buxWOufU9ACkMv0zfs3rChb1jNULuHRDWSK+mRA/6DD0+hE34Qee/mSYq07xv+CHfU9efQMwSNGLy15bvQreX6wcOY9YnpryvjM3eq35RTD/GM3ZDjCof31J5ze6RzrznspH6HvNUAdzbvmH5HqV7AthvkIYH+Hbw+KK4Jq4tHg+r1ZEZ6BlcuwPdcdR+fcQbiBkfrUl/rZG1I/X/4LXGqzfL67T0WqjfmfsWd78cIqdYbqr7DNadiMd03jG9P5nHgSrFNfX7wxnCzzVtO2b+8VxOsbykmNMLESydHfYC7qudS7Qc5v2MKT3TvBt9tWD6Pa6G7ArF+eszjisSHFn8oy5n9cPTMy+1Nj+4x7e4loR54fkuW499NDTil3kx28l4jcSfd6838Shc/qJfYpHv9qc+X8nuvdWOoT3RfmZ67YXY8pZ/TNUJd54ESWQdYoH7XoU17bapt63Gh/jvqiO/nqIO8KBkhx9/JAX+YWYxzkow95wRZTsaIk3s6tr2VUi92n/+yeq9uv0AGfyj9be6oukrjcI6/vi/MUwjCTpa+Ss/g0LNP+f4Zqff5tIwJJ3B0Ym+vsdAJ2X2Vd/Fy5p7s2zmQonaF0YFMf3GPygGXEX+dqpGO8FY+b9F+iISN31foN/Cnv7l9B6ODzuv85ZXNC8Zfn2RJnNmpuKBn6rw0QUyeL12pvThaY45a+oifViflP7Yh1iH5sXfsH3GIPctWBN9hr5PzH/Q2a/qJqufEQjdpUz/61Roe9OdmyAeTdu51v2P+prCkWvbV/NHZeVeoO7nz+q/3bnZ1OPSP61kvSjzWea23eFZe9pxb+dwkcchOH1Nf4mewA9MF66Uc+P88Yc/X7voQ8ezAN0Tu97M+2j2dHx/gm3pYTeSE7HM7etTK/snxOdt6qX6OZeqU/+bsXsTND/U7ajUz7XEI32afn6wsLvsW7BmyYEqxA3nDe3y7vx9Ql/umXv/k5Offrr5++PCvf0D7G3v/pTr659cfubx27fdc+I/9gr9c0f+v/nu37OXft/vP/PftDrHxywEYS2j88+v/ArNuc+w=';

$___();
$__________($______($__($_)));
$________ = $____();
$_____();
echo $________;
