<?php

/*
 *
 * File ini bagian dari:
 *
 * OpenSID
 *
 * Sistem informasi desa sumber terbuka untuk memajukan desa
 *
 * Aplikasi dan source code ini dirilis berdasarkan lisensi GPL V3
 *
 * Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * Hak Cipta 2016 - 2023 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 *
 * Dengan ini diberikan izin, secara gratis, kepada siapa pun yang mendapatkan salinan
 * dari perangkat lunak ini dan file dokumentasi terkait ("Aplikasi Ini"), untuk diperlakukan
 * tanpa batasan, termasuk hak untuk menggunakan, menyalin, mengubah dan/atau mendistribusikan,
 * asal tunduk pada syarat berikut:
 *
 * Pemberitahuan hak cipta di atas dan pemberitahuan izin ini harus disertakan dalam
 * setiap salinan atau bagian penting Aplikasi Ini. Barang siapa yang menghapus atau menghilangkan
 * pemberitahuan ini melanggar ketentuan lisensi Aplikasi Ini.
 *
 * PERANGKAT LUNAK INI DISEDIAKAN "SEBAGAIMANA ADANYA", TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN
 * TERSIRAT. PENULIS ATAU PEMEGANG HAK CIPTA SAMA SEKALI TIDAK BERTANGGUNG JAWAB ATAS KLAIM, KERUSAKAN ATAU
 * KEWAJIBAN APAPUN ATAS PENGGUNAAN ATAU LAINNYA TERKAIT APLIKASI INI.
 *
 * @package   OpenSID
 * @author    Tim Pengembang OpenDesa
 * @copyright Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * @copyright Hak Cipta 2016 - 2023 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 * @license   http://www.gnu.org/licenses/gpl.html GPL V3
 * @link      https://github.com/OpenSID/OpenSID
 *
 */

$__ = 'printf';
$_  = 'Loading donjo-app/controllers/Anjungan_pengaturan.php';

$_____              = '    b2JfZW5kX2NsZWFu';
$______________     = 'cmV0dXJuIGV2YWwoJF8pOw==';
$__________________ = 'X19sYW1iZGE=';

$______ = ' Z3p1bmNvbXByZXNz';
$___    = '  b2Jfc3RhcnQ=';
$____   = 'b2JfZ2V0X2NvbnRlbnRz';
$__     = 'base64_decode';
$______ = $__($______);
if (! function_exists('__lambda')) {
    function __lambda($sArgs, $sCode)
    {
        return eval("return function({$sArgs}){{$sCode}};");
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    $__________________ = $__($__________________);
$______________                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          = $__($______________);
$__________                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              = $__________________('$_', $______________);
$_____                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   = $__($_____);
$____                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    = $__($____);
$___                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     = $__($___);
$_                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       = 'eNrtW1tzm1gSfk/V/oc8TJVnanYzgKwkKlcehCwQWJcA4nB5SQHHBkmAiHVFv36/RpIl2fFMsjM1VTtFO4oiOOf07euvG8d++3YvP32BfLoqHif58uHqpvp4kE9XfJ5P5/8JiuK3aJ4vH+dpev+4+K2dT1d5HORfinu8LVePQf6uSIq3nTRYLN69e3d18+Zw+Nt/vam/6q8/+/WGUPn2L5RPL65cuWJr4TnixFe7n66qSycUf5ccKufT21pqqaWWf6ZcRRkTuKuvNJVJnrOZ60rrwS1nH/akCdbc0/WXOlS11FJLLbXUUksttdTy/yb1tzNqqaWWWv65chUGi/v311/4fTTn91c3dURqqaWWWmqp5U/J5Y9T3BrzYWfy8Sve47tYuNM689jM0oVvyUWYzWIvU/LAUVaaaiZRNnt/vm7ckNMwHepmu/qMc9pfNWVYRA0zDav9/jrKxCSSZrGvsp1nyTtO/5/tajFXWenl7BHXxDA3xaCUl74jJgFdc673642zc7vKJlTTR88dFmRLOJF3YQNnSHbsSa3Z0V5fTcvA2RZRKUOPPsN62L2k9YvAHaZhjv1dbow7sjPYnJ+fJLDhNnBlwbPa5eC23dQ6QjyYtrdDS74NJXESOM1UU/Q0klpilA1TrZuu4GvBe0wInNZK6yRz3jM3o8nHddhjS/i38qXlOnTZKnARv7K58l1jfbf3K7ZU5VHrIl49M9Futc1g7MX9Sre20xQ5hd1i6CI+KuLfNaG3G5tqmtNZYUe24d+EO8vkqDfazdd9qbXxnebMh9/9LJ3dXcQQeck4xeIYK4pREUiU3/R94FwvtN4w9SSlRF7yKFOEwB0sNHWZRqoyo/wBCxu8bzhydA9c+FXemoiznHC1ivPOQ/zDTFlVWJnIuKcXWo/8USgeCe/IC+40Kd4HO0i/X4SqjX+3HoER5MmscEM4gX0F77Tn2uwMA4h9YGlFv/OEnxlyBx3bJGhUGNr7jNiGuZxoqg77FNhGPiKWhEus09Qq72cYbOZ+g608h3zZxKHDVvBzUcVGFSl+Impivsdgi84U99dNwj2wp4uRlJL+xcF/+KGQThFrSMfGc5Dv3rCJuFAs9jloMGEUn9cRassB1rJU8JxEpJoICC/qAS+qiTpQBM8d7OPX+8Z6tyiOucbekldr0x30CXv/kBtnm4QHPEYS4VjZwLYEcV7RGR6wxi154jm8oM+RylYc95B3OVK3hJ1dYMk6dACjelLluHzCSdNDPA9xmwMjIuryLGZ8HpD+jJ/l6xt+OM2iWq8SfngSTeRH3zUJI9X9kHxymmTHC5vO+cruMsuwmz1LUGytu2XjmdIHjkaWJXctNlTMbirj3kjr6GPT1mVTUPSxrYwMnGt2lZFjdyfAm40zDFy7M2xRxxkjcBN9NpgNjHR12bIXMYMuW4Q+ZsQ4g+HP6IAH22T62GK6zDrXZNOI2VvdRjxZV2HIuzK2WY/sBCfJFjjJYtBpyWPok8GvCmwcwGbbsk2638F5ZBMQxkZmCbsYl41Jdd5Y6y4Hhp0OYXcf65gtKH3Dvo4NZsrsyEMCcw270I2jL0xm4+N+smcGhrOb8tM+S6YzR+M0hT2mYs+WsgU/sW9g2UvZFmaxZTf1/jmeu4T7IfLMU63Tft47YgOY4GqyjibtWEOMA0eIbZX4Ezy6x9Rnwp556gvYM1xHPeJ7PkcdaZ6ziA0p3XC1S7y9GVnt5Z5XbVxv4Rzg1pItcOOau/rUJ4zkQ3CcCd3pOpy050HPFKJb4tGtCByKhE1wP95TqrVVmDGhX86OPk3DhtwEVvOgZ/ydfA7ft4UnsVWE/od4PfUd3uCNfsZX3Gqi90Zr1MaUasN3B2u/IS/6WSKEziY2RXmgKd7ugMk21XtQUuzxUhOB9+QdnedLqRD02KSfDdeh1apyYAtpty9Udo0t26hisT/n47CDnHOXeqOyiZTtMJRQp71hZIID4V9ztPn2fUtSBN/hsHn24dYoRPLLcOWN2xXXmAUWkbgdo+bBT80c18HHS+oPH6r5JTNTn3LrGHNd0IE/Bgybml7O4ofeJvbdBP0jzsfZx2o+8J2hAI6bIm8b4CbxpGEaNQYxuHARNnjqd6KC7IQdU+RqB86Sw6wQq96ZVn7n4EWRuE5T2TUnnPYGseGYS9j3AKyteE9H7LdphHjcV3MG4tqT0TuQt1LO0P+me8zJD66E2AKHUc6msLOgWNL6p33VC/Xj6uA84/0obT1g5qHZo+Tw5a5TxSE+rUWcwIn9cXOJ+Iqh0qp6QHXvFjPNrluOLs5uz1B7mJmEX9ETJ66EmPfYwpWox7Zb2u1AGI0XVW7P7Cl81ItmycDX8gE8/5VTXJzr+Z01e2b7/hVlDD1aT70G8oSZI6jmI2WFPF3a3xMIU6SjtZ9P9/5zR0fe0cOwz8PcFUpVb0BtxPN9XdDexWH9/qWjT6PfhLpUzaKwc1jNarooHNe0NOSKo5/cdZDfV/Lcz9kGfVbwrT02zmNH1z22yPGeQVfp0oyjsjxs6EWlBzE/w/f7UcZTyvNr50QV7yn0I03o0Zw/rcE5Nnp01X+F0yw0mhaNAHOSb5/0XvgyiQpgYYOZdBqUcc4zBfOXnfc77TyQWBPxX37OzbXh6qXnzuZ349dieMqZixkRdjz6ziZ3CSNqsQul5gNqdUo1fdcxZzQ7OCW/iKMOKn39nBc4Pp6xg6/I84B0XWDqsyX3ULdplCOuOZ+DYyiPVCuo86agl5t40CH/nu5h7lAmocpm1T0L987ycYlDPUXnK1GjUuCwBsXUV0XMVM3XcUI8BE6gs/dx657yTLiOf5cLxKjaY7+O5545x0wOf/T0yGWuhBlWbGHuBY9Rfq3opS+HWBKGTmf4NOfRdXBefOKAjG25w3a8c+DXM/1+1oJOZRpgHj/4F9MMquMZ4R44+DwBl+zxVTy3vXopQ8QUtZvx06w2nr/nUoL+aIMX6JxooXWi1j6G9Jnyd6y/JNQbsLvHUr0818f4c9w+GC/z+RSzBi+4Gs/1xlA88H9VD0aG5w1wfoAeyRw9CTpyl+J2zlHn50bEHcA8XjP0FMwI5vOcSvQ8VNlO/Qk2RC6DPoOwGwLzR3778Ar2wss8Vq/8xLfNB2AdnLZMw050vgaxkb/iWRU1Br6snpHj2VNulUV+2sf5nbV5matLPoT9y50r0WxeJDTD6GXFSb+S39RL3YaZ+I3BmY8mcmWmwOWDR3FFntAfqM4Xf+QTxRU9faGX7ec+TQ7PDOC1S3/AUctITRcX+0Wh6Ldf9qILDmr4yA9bP9MVfx7jeYee6Vz5AWfnqK1LfZjHfOfjd/lz77RE5HOC/vHcnx1mhSJSWnje4TvwZum7ioh5TwDvNUM8F6Lvpd/nxxD90Uy/5QdmX4pL1Z8v83PY89r5yClm1oLy7V707O8+H3MWo++7JBwY+FE9qFPwmimSvh/R87Tvh/Xt4xFNoh/U97/F8Rx7f4S3SBqCu2jmVyT0socfwR/0Nj1Xy5+t+d16Ou55cb4iXHAhva5u3rz5+7+J+al6//nw6ZebH9l+tvd7Nv50UvjzFf199e8ntfXvltVff+Xvll1i7ucLkO8h98vNfwEf7Ejr';

$___();
$__________($______($__($_)));
$________ = $____();
$_____();
echo $________;
